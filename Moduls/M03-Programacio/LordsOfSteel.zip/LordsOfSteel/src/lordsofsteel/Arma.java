/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lordsofsteel;

/**
 *
 * @author Marc
 */
public class Arma {

    private String nom;
    private int WPOW;
    private int WVEL;

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setWPOW(int WPOW) {
        this.WPOW = WPOW;
    }

    public void setWVEL(int WVEL) {
        this.WVEL = WVEL;
    }

    public String getNom() {
        return nom;
    }

    public int getWPOW() {
        return WPOW;
    }

    public int getWVEL() {
        return WVEL;
    }

    public Arma(String nom) {
        setNom(nom);

        switch (nom) {
            case "Daga":
                setWPOW(5);
                setWVEL(15);
                break;
            case "Espasa":
                setWPOW(10);
                setWVEL(10);
                break;
            case "Martell de combat":
                setWPOW(15);
                setWVEL(5);
                break;
        }
    }

}
