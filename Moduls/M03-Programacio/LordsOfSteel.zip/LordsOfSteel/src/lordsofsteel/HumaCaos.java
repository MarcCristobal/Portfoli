/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lordsofsteel;

/**
 *
 * @author Marc
 */
public class HumaCaos extends Huma implements Caos {

    public HumaCaos(String nom, int FOR, int CON, int VEL, int INT, int SOR, String arma) {
        super(nom, FOR, CON, VEL, INT, SOR, arma);
    }

    public boolean contraatac(int tirada) {
        if (tirada < (getPA() * 0.5)) {
            return true;
        }

        return false;
    }

}
