/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lordsofsteel;

/**
 *
 * @author Marc
 */
public class HumaOrdre extends Huma implements Ordre {

    public HumaOrdre(String nom, int FOR, int CON, int VEL, int INT, int SOR, int arma) {
        super(nom, FOR, CON, VEL, INT, SOR, arma);
    }
    
    public HumaOrdre(String nom, int FOR, int CON, int VEL, int INT, int SOR, int arma, int PEX, int NIV) {
        super(nom, FOR, CON, VEL, INT, SOR, arma, PEX, NIV);
    }

    public void restaurar10PerPS() {
        int psInicials = getCON() + getFOR() + getINT();
        int deuPer = (int) (psInicials * 0.1);

        if (getPS() != psInicials) {
            if (getPS() + deuPer > psInicials) {
                setPS(psInicials);
            } else {
                setPS(getPS() + deuPer);
            }
        }
    }
}
