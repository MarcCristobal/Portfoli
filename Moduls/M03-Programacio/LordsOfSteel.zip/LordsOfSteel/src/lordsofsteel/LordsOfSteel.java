/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lordsofsteel;

import java.util.Scanner;

/**
 *
 * @author Marc
 */
public class LordsOfSteel {

    public static Scanner sc = new Scanner(System.in);
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int opcio = 0;
        
        NanCaos gimli = new NanCaos("Gimli", 18, 18, 8, 8, 8, 3);
        HumaOrdre aragorn = new HumaOrdre("Aragorn", 14, 14, 12, 10, 10, 2);
        
        
        System.out.println("----- Lords Of Steel -----\n");
        
        do{
            System.out.println("--- Menú principal ---\n");
            System.out.println("(1) Afegir nou personatge");
            System.out.println("(2) Esborrar personatge");
            System.out.println("(3) Editar personatge");
            System.out.println("(4) Iniciar un combat");
            System.out.println("(5) Sortir\n");
            
            System.out.print("Escull una de les opcions disponibles: ");
            opcio = sc.nextInt();
            System.out.println("");
            
            switch (opcio){
                case 1: break;
                case 2: break;
                case 3: break;
                case 4: break;
                case 5: break;
                default: System.out.println("Opció no vàlida"); break;
            }
        
        }while(opcio != 5);
        
        
    }
    
}
