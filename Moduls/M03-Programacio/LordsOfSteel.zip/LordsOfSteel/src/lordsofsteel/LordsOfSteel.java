/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lordsofsteel;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Marc
 */
public class LordsOfSteel {

    public static Scanner sc = new Scanner(System.in);

    public static List<Personatge> personatges = new ArrayList<>();

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        String nom = "";
        int opcio = 0;
        int FOR;
        int CON;
        int VEL;
        int INT;
        int SOR;
        int arma;
        int categoria;
        int devocio;
        int index = 0;
        int dau1;
        int dau2;
        int dau3;
        int tiradaAtacant;
        int tiradaDefensor;
        int nivAux;
        Personatge atacant = null;
        Personatge defensor = null;
        Personatge guanyador = null;
        Personatge perdedor = null;
        boolean victoria = false;

        personatges.add(new NanCaos("Gimli", 18, 18, 8, 8, 8, 3));
        personatges.add(new HumaOrdre("Aragorn", 14, 14, 12, 10, 10, 2));
        personatges.add(new MitjaCaos("Legolas", 10, 10, 16, 12, 12, 2));
        personatges.add(new MaiaOrdre("Gandalf", 8, 10, 12, 15, 15, 1));

        System.out.println("----- Lords Of Steel -----\n");

        do {
            System.out.println("--- Menú principal ---\n");
            System.out.println("(1) Afegir nou personatge");
            System.out.println("(2) Esborrar personatge");
            System.out.println("(3) Editar personatge");
            System.out.println("(4) Iniciar un combat");
            System.out.println("(5) Sortir\n");

            System.out.print("Escull una de les opcions disponibles: ");
            opcio = sc.nextInt();
            System.out.println("");

            switch (opcio) {
                case 1:
                    System.out.println("--- Creació de personatge ---\n");
                    System.out.println("Introdueix les següents dades:");

                    do {
                        System.out.print("Nom del personatge: ");
                        nom = sc.next();
                        sc.nextLine();
                        System.out.println("");

                        if (!nomDisponible(nom)) {
                            System.out.println("El personatge amb nom " + nom + " ja existeix. Escull un altre nom.\n");
                        }
                    } while (!nomDisponible(nom));

                    do {
                        System.out.println("Valors de les estadístiques (60 punts a repartir. Valor mínim 3, valor màxim 18):");

                        do {
                            System.out.print("FOR (força): ");
                            FOR = sc.nextInt();

                            if (!statValida(FOR)) {
                                System.out.println("\nEl valor està fora de rang. Torna a afegir un nou valor.\n");
                            }
                        } while (!statValida(FOR));

                        do {
                            System.out.print("CON (constitució): ");
                            CON = sc.nextInt();

                            if (!statValida(CON)) {
                                System.out.println("\nEl valor està fora de rang. Torna a afegir un nou valor.\n");
                            }
                        } while (!statValida(CON));

                        do {
                            System.out.print("VEL (velocitat): ");
                            VEL = sc.nextInt();

                            if (!statValida(VEL)) {
                                System.out.println("\nEl valor està fora de rang. Torna a afegir un nou valor.\n");
                            }
                        } while (!statValida(VEL));

                        do {
                            System.out.print("INT (intel·ligència): ");
                            INT = sc.nextInt();

                            if (!statValida(INT)) {
                                System.out.println("\nEl valor està fora de rang. Torna a afegir un nou valor.\n");
                            }
                        } while (!statValida(INT));

                        do {
                            System.out.print("SOR (sort): ");
                            SOR = sc.nextInt();
                            System.out.println("");

                            if (!statValida(SOR)) {
                                System.out.println("El valor està fora de rang. Torna a afegir un nou valor.\n");
                            }
                        } while (!statValida(SOR));

                        if (!statsValides(FOR, CON, VEL, INT, SOR)) {
                            System.out.println("\nLa suma dels valors de les estadístiques no suma 60. Torna a repartir els punts disponibles.\n");
                        }
                    } while (!statsValides(FOR, CON, VEL, INT, SOR));

                    do {
                        System.out.println("Armes disponibles:");
                        System.out.println("(1) Daga -> WPOW (poder de l'arma: 5, WVEL (velocitat de l'arma): 15");
                        System.out.println("(2) Espasa -> WPOW (poder de l'arma: 10, WVEL (velocitat de l'arma): 10");
                        System.out.println("(3) Martell de combat -> WPOW (poder de l'arma: 15, WVEL (velocitat de l'arma): 5\n");
                        System.out.print("Arma a escollir: ");
                        arma = sc.nextInt();
                        System.out.println("");

                        if (!armaValida(arma)) {
                            System.out.println("Opció no disponible. Torna a escollir un arma disponible.\n");
                        }
                    } while (!armaValida(arma));

                    do {
                        System.out.println("Categoríes disponibles:");
                        System.out.println("(1) Nan. s’especialitza en el dany.");
                        System.out.println("(2) Humà, s’especialitza en la resistència.");
                        System.out.println("(3) Mitjà, s’especialitza en esquivar.");
                        System.out.println("(4) Maia, s’especialitza en l’atac.\n");
                        System.out.print("Categoría a escollir: ");
                        categoria = sc.nextInt();
                        System.out.println("");

                        if (!categoriaValida(categoria)) {
                            System.out.println("Opció no vàlida. Torna a escollir una categoría disponible.");
                        }
                    } while (!categoriaValida(categoria));

                    do {
                        System.out.println("Devocions disponibles:");
                        System.out.println("(1) Ordre: cada cop que el personatge amb aquesta devoció encerta un atac i l’oponent falla l’esquiva,\n"
                                + "el personatge recupera un 10% dels seus PS (punts de salut) inicials (sense arribar a superar el màxim). ");
                        System.out.println("(2) Caos: si el personatge amb aquesta devoció encerta una esquiva, té l’oportunitat de contraatacar,\n"
                                + "amb una PA (probabilitat d'atacar) un 50% inferior: PA’ = 0.5 * PA. En aquest cas, l’oponent no té l'oportunitat de\n"
                                + "provar d’esquivar, de manera que si el contraatac té èxit, rebrà els PD (punts de dany) corresponents.\n");
                        System.out.print("Devoció a escollir: ");
                        devocio = sc.nextInt();
                        System.out.println("");

                        if (!devocioValida(devocio)) {
                            System.out.println("Opció no vàlida. Torna a escollir una devoció disponible.");
                        }
                    } while (!devocioValida(devocio));

                    personatges.add(crearPersonatge(nom, FOR, CON, VEL, INT, SOR, arma, categoria, devocio));

                    System.out.println("Personatge creat amb èxit.\n");
                    break;

                case 2:
                    System.out.println("--- Eliminar un personatge ---\n");

                    do {
                        index = 0;
                        System.out.println("--- Llista de personatges ---\n");
                        for (Personatge personatge : personatges) {
                            System.out.println("(" + index + ") " + personatge.toString());
                            index++;
                        }

                        System.out.print("Personatge a eliminar: ");
                        index = sc.nextInt();
                        System.out.println("");

                        if (!personatgeDisponible(index)) {
                            index = -1;
                            System.out.println("Opció no vàlida. Torna a escollir un personatge disponible.\n");
                        }
                    } while (!personatgeDisponible(index));

                    personatges.remove(index);
                    index = 0;

                    System.out.println("Personatge eliminat amb èxit.\n");
                    break;

                case 3:
                    System.out.println("--- Modificar un personatge ---\n");

                    do {
                        index = 0;

                        System.out.println("--- Llista de personatges ---\n");
                        for (Personatge personatge : personatges) {
                            System.out.println("(" + index + ") " + personatge.toString());
                            index++;
                        }

                        System.out.print("Personatge a modificar: ");
                        index = sc.nextInt();
                        System.out.println("");

                        if (!personatgeDisponible(index)) {
                            index = -1;
                            System.out.println("Opció no vàlida. Torna a escollir un personatge disponible.\n");
                        }
                    } while (!personatgeDisponible(index));

                    do {
                        System.out.println("Valors de les estadístiques (60 punts a repartir. Valor mínim 3, valor màxim 18):");

                        do {
                            System.out.print("FOR (força): ");
                            FOR = sc.nextInt();

                            if (!statValida(FOR)) {
                                System.out.println("El valor de l'estadística està fora de rang. Torna a afegir un nou valor.\n");
                            }
                        } while (!statValida(FOR));

                        do {
                            System.out.print("CON (constitució): ");
                            CON = sc.nextInt();

                            if (!statValida(CON)) {
                                System.out.println("El valor està fora de rang. Torna a afegir un nou valor.\n");
                            }
                        } while (!statValida(CON));

                        do {
                            System.out.print("VEL (velocitat): ");
                            VEL = sc.nextInt();

                            if (!statValida(VEL)) {
                                System.out.println("El valor està fora de rang. Torna a afegir un nou valor.\n");
                            }
                        } while (!statValida(VEL));

                        do {
                            System.out.print("INT (intel·ligència): ");
                            INT = sc.nextInt();

                            if (!statValida(INT)) {
                                System.out.println("El valor està fora de rang. Torna a afegir un nou valor.\n");
                            }
                        } while (!statValida(INT));

                        do {
                            System.out.print("SOR (sort): ");
                            SOR = sc.nextInt();

                            if (!statValida(SOR)) {
                                System.out.println("El valor està fora de rang. Torna a afegir un nou valor.\n");
                            }
                        } while (!statValida(SOR));

                        if (!statsValides(FOR, CON, VEL, INT, SOR)) {
                            System.out.println("La suma dels valors de les estadístiques no suma 60. Torna a repartir els punts disponibles.\n");
                        }
                    } while (!statsValides(FOR, CON, VEL, INT, SOR));

                    personatges.set(index, modificaPersonatge(personatges.get(index), FOR, CON, VEL, INT, SOR));
                    index = 0;

                    System.out.println("Personatge modificat amb èxit.\n");
                    break;

                case 4:
                    int[] ind = new int[2];

                    System.out.println("--- Nou Combat ---\n");

                    do {
                        index = 0;

                        System.out.println("--- Llista de personatges ---\n");
                        for (Personatge personatge : personatges) {
                            System.out.println("(" + index + ") " + personatge.toString());
                            index++;
                        }

                        System.out.print("Primer personatge (comença atacant): ");
                        index = sc.nextInt();
                        System.out.println("");

                        if (!personatgeDisponible(index)) {
                            index = -1;
                            System.out.println("\nOpció no vàlida. Torna a escollir un personatge disponible.\n");
                        } else {
                            ind[0] = index;

                        }
                    } while (!personatgeDisponible(index));

                    do {
                        index = 0;

                        System.out.println("--- Llista de personatges ---\n");
                        for (Personatge personatge : personatges) {
                            System.out.println("(" + index + ") " + personatge.toString());
                            index++;
                        }

                        System.out.print("Segon personatge (comença defensant): ");
                        index = sc.nextInt();
                        System.out.println("");

                        if (!personatgeDisponible(index)) {
                            index = -1;
                            System.out.println("Opció no vàlida. Torna a escollir un personatge disponible.\n");
                        } else if (index == ind[0]) {
                            System.out.println("Opcio ja escollida com a atacant. Torna a escollir un personatge disponible.\n");
                        } else {
                            ind[1] = index;
                        }
                    } while (!personatgeDisponible(index) || index == ind[0]);

                    index = 0;

                    System.out.println("Personatges escollits amb èxit. Que comenci el combat!\n");

                    do {
                        atacant = personatges.get(ind[0]);
                        defensor = personatges.get(ind[1]);

                        System.out.println("Atac del personatge " + atacant.getNom());
                        System.out.println("Primer dau: " + (dau1 = tiraDau()));
                        System.out.println("Segon dau: " + (dau2 = tiraDau()));
                        System.out.println("Tercer dau: " + (dau3 = tiraDau()));
                        tiradaAtacant = dau1 + dau2 + dau3;
                        System.out.println("Total tirada: " + tiradaAtacant + "\n");

                        if (!tiradaValida(atacant.getPA(), tiradaAtacant)) {
                            System.out.println(atacant.getNom() + " falla l'atac.\n");
                        } else {
                            System.out.println(atacant.getNom() + " encerta la tirada d'atac!\n");
                            System.out.println("Defensa del personatge " + defensor.getNom() + ".");
                            System.out.println("Primer dau: " + (dau1 = tiraDau()));
                            System.out.println("Segon dau: " + (dau2 = tiraDau()));
                            System.out.println("Tercer dau: " + (dau3 = tiraDau()));
                            tiradaDefensor = dau1 + dau2 + dau3;
                            System.out.println("Total tirada: " + tiradaDefensor + "\n");

                            if (!tiradaValida(defensor.getPE(), tiradaDefensor)) {
                                System.out.println(defensor.getNom() + " falla l'esquiva.\n");

                                if (atacant.getClass().getSimpleName().contains("Ordre")) {
                                    System.out.println(atacant.getNom() + " recupera un 10% dels PS.\n");

                                    switch (atacant.getClass().getSimpleName()) {
                                        case "NanOrdre":
                                            ((NanOrdre) atacant).restaurar10PerPS();
                                            break;
                                        case "HumaOrdre":
                                            ((HumaOrdre) atacant).restaurar10PerPS();
                                            break;
                                        case "MitjaOrdre":
                                            ((MitjaOrdre) atacant).restaurar10PerPS();
                                            break;
                                        case "MaiaOrdre":
                                            ((MaiaOrdre) atacant).restaurar10PerPS();
                                            break;
                                    }
                                }

                                System.out.println(atacant.getNom() + " ataca amb èxit a " + defensor.getNom());

                                defensor.rebreDany(atacant.getPD());

                                if (defensor.getPS() > 0) {
                                    System.out.println("A " + defensor.getNom() + " li resten " + defensor.getPS() + " PS.\n");
                                } else {
                                    System.out.println(defensor.getNom() + " ha perdut tots els PS");
                                    guanyador = atacant;
                                    perdedor = defensor;
                                    victoria = true;
                                }
                            } else {
                                System.out.println(defensor.getNom() + " encerta la tirada d'esquiva!");
                                System.out.println(defensor.getNom() + " esquiva amb èxit a " + atacant.getNom() + "\n");

                                if (defensor.getClass().getSimpleName().contains("Caos")) {
                                    System.out.println("Tirada de contraatac");
                                    System.out.println("Primer dau: " + (dau1 = tiraDau()));
                                    System.out.println("Segon dau: " + (dau2 = tiraDau()));
                                    System.out.println("Tercer dau: " + (dau3 = tiraDau()));
                                    tiradaDefensor = dau1 + dau2 + dau3;
                                    System.out.println("Total tirada: " + tiradaDefensor + "\n");

                                    switch (defensor.getClass().getSimpleName()) {
                                        case "NanCaos":
                                            if (!((NanCaos) defensor).contraatac(tiradaDefensor)) {
                                                System.out.println(defensor.getNom() + " falla el contraatac.\n");
                                            } else {
                                                System.out.println(defensor.getNom() + " contraataca amb èxit a " + atacant.getNom());

                                                atacant.rebreDany(defensor.getPD());

                                                if (atacant.getPS() > 0) {
                                                    System.out.println("A " + atacant.getNom() + " li resten " + atacant.getPS() + " PS.\n");
                                                } else {
                                                    System.out.println(atacant.getNom() + " ha perdut tots els PS");
                                                    guanyador = defensor;
                                                    perdedor = atacant;
                                                    victoria = true;
                                                }
                                            }
                                            ;
                                            break;
                                        case "HumaCaos":
                                            if (!((HumaCaos) defensor).contraatac(tiradaDefensor)) {
                                                System.out.println(defensor.getNom() + " falla el contraatac.\n");
                                            } else {
                                                System.out.println(defensor.getNom() + " contraataca amb èxit a " + atacant.getNom());

                                                atacant.rebreDany(defensor.getPD());

                                                if (atacant.getPS() > 0) {
                                                    System.out.println("A " + atacant.getNom() + " li resten " + atacant.getPS() + " PS.\n");
                                                } else {
                                                    System.out.println(atacant.getNom() + " ha perdut tots els PS");
                                                    guanyador = defensor;
                                                    perdedor = atacant;
                                                    victoria = true;
                                                }
                                            }
                                            ;
                                            break;
                                        case "MitjaCaos":
                                            if (!((MitjaCaos) defensor).contraatac(tiradaDefensor)) {
                                                System.out.println(defensor.getNom() + " falla el contraatac.\n");
                                            } else {
                                                System.out.println(defensor.getNom() + " contraataca amb èxit a " + atacant.getNom());

                                                atacant.rebreDany(defensor.getPD());

                                                if (atacant.getPS() > 0) {
                                                    System.out.println("A " + atacant.getNom() + " li resten " + atacant.getPS() + " PS.\n");
                                                } else {
                                                    System.out.println(atacant.getNom() + " ha perdut tots els PS");
                                                    guanyador = defensor;
                                                    perdedor = atacant;
                                                    victoria = true;
                                                }
                                            }
                                            ;
                                            break;
                                        case "MaiaCaos":
                                            if (!((MaiaCaos) defensor).contraatac(tiradaDefensor)) {
                                                System.out.println(defensor.getNom() + " falla el contraatac.\n");
                                            } else {
                                                System.out.println(defensor.getNom() + " contraataca amb èxit a " + atacant.getNom());

                                                atacant.rebreDany(defensor.getPD());

                                                if (atacant.getPS() > 0) {
                                                    System.out.println("A " + atacant.getNom() + " li resten " + atacant.getPS() + " PS.\n");
                                                } else {
                                                    System.out.println(atacant.getNom() + " ha perdut tots els PS");
                                                    guanyador = defensor;
                                                    perdedor = atacant;
                                                    victoria = true;
                                                }
                                            }
                                            ;
                                            break;
                                    }
                                }
                            }
                        }

                        ind = canviTorn(ind);
                        atacant = personatges.get(ind[0]);
                        defensor = personatges.get(ind[1]);
                        index = 0;

                    } while (!victoria);

                    guanyador.restaurarPS();
                    perdedor.restaurarPS();
                    nivAux = guanyador.getNIV();
                    guanyador.augmentarPEX(perdedor.getPS());
                    index = 0;

                    System.out.println(guanyador.getNom() + " és el guanyador del combat!");
                    System.out.println(guanyador.getNom() + " guanya " + perdedor.getPS() + " PEX.");

                    if (nivAux != guanyador.getNIV()) {
                        System.out.println(guanyador.getNom() + " puja al nivell " + guanyador.getNIV() + "!.");
                    }

                    System.out.println("El combat ha finalitzat.\n");
                    break;
                case 5:
                    break;
                default:
                    System.out.println("Opció no vàlida. Torna a escollir una opció disponible.\n");
                    break;
            }

        } while (opcio != 5);

        System.out.println("Fins aviat!\n");

    }

    public static int[] canviTorn(int[] canvi) {
        int tmp = canvi[0];
        canvi[0] = canvi[1];
        canvi[1] = tmp;

        return canvi;
    }

    public static boolean tiradaValida(int stat, int tirada) {
        if (tirada <= stat) {
            return true;
        }

        return false;
    }

    public static int tiraDau() {
        return (int) ((Math.random() * 25) + 1);
    }

    public static boolean personatgeDisponible(int index) {
        if (index < 0 || index >= personatges.size()) {
            return false;
        }

        return true;
    }

    public static Personatge modificaPersonatge(Personatge p, int FOR, int CON, int VEL, int INT, int SOR) {
        p.setFOR(FOR + p.getNIV());
        p.setCON(CON + p.getNIV());
        p.setVEL(VEL + p.getNIV());
        p.setINT(INT + p.getNIV());
        p.setSOR(SOR + p.getNIV());
        p.statsSecundaries(p.getArma());

        return p;
    }

    public static Personatge crearPersonatge(String nom, int FOR, int CON, int VEL, int INT, int SOR, int arma, int categoria, int devocio) {
        switch (devocio) {
            case 1:
                switch (categoria) {
                    case 1:
                        return new NanOrdre(nom, FOR, CON, VEL, INT, SOR, arma);
                    case 2:
                        return new HumaOrdre(nom, FOR, CON, VEL, INT, SOR, arma);
                    case 3:
                        return new MitjaOrdre(nom, FOR, CON, VEL, INT, SOR, arma);
                    case 4:
                        return new MaiaOrdre(nom, FOR, CON, VEL, INT, SOR, arma);
                }
            case 2:
                switch (categoria) {
                    case 1:
                        return new NanCaos(nom, FOR, CON, VEL, INT, SOR, arma);
                    case 2:
                        return new HumaCaos(nom, FOR, CON, VEL, INT, SOR, arma);
                    case 3:
                        return new MitjaCaos(nom, FOR, CON, VEL, INT, SOR, arma);
                    case 4:
                        return new MaiaCaos(nom, FOR, CON, VEL, INT, SOR, arma);
                }
        }
        return null;
    }

    public static boolean nomDisponible(String nom) {

        for (Personatge personatge : personatges) {
            String aux = personatge.getNom();
            if (nom.equalsIgnoreCase(aux)) {
                return false;
            }
        }
        return true;
    }

    public static boolean armaValida(int opcio) {
        if (opcio == 1 || opcio == 2 || opcio == 3) {
            return true;
        }

        return false;
    }

    public static boolean categoriaValida(int opcio) {
        if (opcio == 1 || opcio == 2 || opcio == 3 || opcio == 4) {
            return true;
        }

        return false;
    }

    public static boolean devocioValida(int opcio) {
        if (opcio == 1 || opcio == 2) {
            return true;
        }

        return false;
    }

    public static boolean statValida(int stat) {
        if (stat >= 3 && stat <= 18) {
            return true;
        }

        return false;
    }

    public static boolean statsValides(int s1, int s2, int s3, int s4, int s5) {
        int sumaStats = s1 + s2 + s3 + s4 + s5;

        if (sumaStats != 60) {
            return false;
        }

        return true;
    }

}
