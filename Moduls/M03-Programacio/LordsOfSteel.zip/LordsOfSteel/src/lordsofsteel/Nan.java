/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lordsofsteel;

/**
 *
 * @author Marc
 */
public class Nan extends Personatge {

    public Nan(String nom, int FOR, int CON, int VEL, int INT, int SOR, int arma) {
        super(nom, FOR, CON, VEL, INT, SOR, arma);
    }
    
    public Nan(String nom, int FOR, int CON, int VEL, int INT, int SOR, int arma, int PEX, int NIV) {
        super(nom, FOR, CON, VEL, INT, SOR, arma, PEX, NIV);
    }

    public void statsSecundaries() {
        setPS(getCON() + getFOR());
        setPD((getFOR() + getArma().getWPOW() + getCON()) / 4);
        setPA(getINT() + getSOR() + getArma().getWVEL());
        setPE(getVEL() + getSOR() + getINT());
    }

}
