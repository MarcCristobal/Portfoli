/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lordsofsteel;

/**
 *
 * @author Marc
 */
public class NanCaos extends Nan implements Caos {

    public NanCaos(String nom, int FOR, int CON, int VEL, int INT, int SOR, int arma) {
        super(nom, FOR, CON, VEL, INT, SOR, arma);
    }
    
    public NanCaos(String nom, int FOR, int CON, int VEL, int INT, int SOR, int arma, int PEX, int NIV) {
        super(nom, FOR, CON, VEL, INT, SOR, arma, PEX, NIV);
    }

    public boolean contraatac(int tirada) {
        if (tirada < (getPA() * 0.5)) {
            return true;
        }

        return false;
    }

}
