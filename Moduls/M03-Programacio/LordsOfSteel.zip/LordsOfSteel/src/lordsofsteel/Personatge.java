/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lordsofsteel;

/**
 *
 * @author Marc
 */
public abstract class Personatge {

    private String nom;
    private int FOR;
    private int CON;
    private int VEL;
    private int INT;
    private int SOR;
    private int PS;
    private int PD;
    private int PA;
    private int PE;
    private Arma arma;
    private int PEX;
    private int NIV;

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setFOR(int FOR) {
        this.FOR = FOR;
    }

    public void setCON(int CON) {
        this.CON = CON;
    }

    public void setVEL(int VEL) {
        this.VEL = VEL;
    }

    public void setINT(int INT) {
        this.INT = INT;
    }

    public void setSOR(int SOR) {
        this.SOR = SOR;
    }

    public void setPS(int PS) {
        this.PS = PS;
    }

    public void setPD(int PD) {
        this.PD = PD;
    }

    public void setPA(int PA) {
        this.PA = PA;
    }

    public void setPE(int PE) {
        this.PE = PE;
    }

    public void setArma(String nom) {
        arma = new Arma(nom);
    }

    public void setPEX(int PEX) {
        this.PEX = PEX;
    }

    public void setNIV(int NIV) {
        this.NIV = NIV;
    }

    public String getNom() {
        return nom;
    }

    public int getFOR() {
        return FOR;
    }

    public int getCON() {
        return CON;
    }

    public int getVEL() {
        return VEL;
    }

    public int getINT() {
        return INT;
    }

    public int getSOR() {
        return SOR;
    }

    public int getPS() {
        return PS;
    }

    public int getPD() {
        return PD;
    }

    public int getPA() {
        return PA;
    }

    public int getPE() {
        return PE;
    }

    public Arma getArma() {
        return arma;
    }

    public int getPEX() {
        return PEX;
    }

    public int getNIV() {
        return NIV;
    }

    public abstract void statsSecundaries();

    public Personatge(String nom, int FOR, int CON, int VEL, int INT, int SOR, String arma) {
        setNom(nom);
        setFOR(FOR);
        setCON(CON);
        setVEL(VEL);
        setINT(INT);
        setSOR(SOR);
        statsSecundaries();
        setArma(arma);
        setPEX(0);
        setNIV(0);
    }

    public void rebreDany(int dany) {
        setPS(getPS() - dany);
    }
    
    public void restaurarPS(){
        setPS(getCON() + getFOR());
    }

    public void augmentarPEX(int psRival) {
        setPEX(getPEX() + psRival);

        if ((getNIV() == 0 && getPEX() <= 100) || (getNIV() == 1 && getPEX() <= 200) || (getNIV() == 2 && getPEX() <= 500)
                || (getNIV() == 3 && getPEX() <= 1000) || (getNIV() == 4 && getPEX() <= 2000)) {
            augmentarNIV();
        }
    }

    public void augmentarNIV() {
        setNIV(getNIV() + 1);
        setFOR(getFOR() + 1);
        setCON(getCON() + 1);
        setVEL(getVEL() + 1);
        setINT(getINT() + 1);
        setSOR(getSOR() + 1);
        statsSecundaries();

        switch (getNIV()) {
            case 1:
                setPEX(getPEX() - 100);
                break;
            case 2:
                setPEX(getPEX() - 200);
                break;
            case 3:
                setPEX(getPEX() - 500);
                break;
            case 4:
                setPEX(getPEX() - 1000);
                break;
            case 5:
                setPEX(getPEX() - 2000);
                break;
        }
    }

}
